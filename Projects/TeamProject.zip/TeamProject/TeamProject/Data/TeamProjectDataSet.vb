﻿

Partial Public Class TeamProjectDataSet
End Class


Partial Public Class TeamProjectDataSet
End Class

Namespace TeamProjectDataSetTableAdapters

    Partial Public Class EmployeeTableAdapter
    End Class
End Namespace
