﻿Public Class FormAppts
    Private Sub btnAddAppt_Click(sender As Object, e As EventArgs) Handles btnAddAppt.Click
        FormEditAppt.Show()
    End Sub
End Class