﻿Public Class FormJobs
    Private Sub btnAddJob_Click(sender As Object, e As EventArgs) Handles btnAddJob.Click
        FormEditJob.Show()
    End Sub
End Class