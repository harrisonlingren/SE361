﻿Public Class FormEditJob
    Private Sub btnJobCancel_Click(sender As Object, e As EventArgs) Handles btnJobCancel.Click
        Me.Close()
    End Sub
End Class