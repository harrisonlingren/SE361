﻿Public Class cCustomer

End Class
