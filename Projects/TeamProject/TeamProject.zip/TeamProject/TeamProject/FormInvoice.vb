﻿Public Class FormInvoice
    Private Sub btnAddInvoice_Click(sender As Object, e As EventArgs) Handles btnAddInvoice.Click
        FormEditInvoice.Show()
    End Sub
End Class