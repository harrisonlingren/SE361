﻿Public Class FormEmployees
    Private Sub btnAddEmp_Click(sender As Object, e As EventArgs) Handles btnAddEmp.Click
        FormEditEmployee.Show()
    End Sub
End Class